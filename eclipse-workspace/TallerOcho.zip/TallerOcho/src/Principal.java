import java.util.Scanner;

public class Principal {
	public static void main(String args[]) {
		
		puntoSiete resultados = new puntoSiete();		
		//resultados.promedio();
		
		puntoOcho arreglos = new puntoOcho();
		arreglos.menu();
	}
}

